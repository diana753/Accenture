package co.accenture.labdevops;

/**
 *
 * @author diego.tapia
 */
public enum BrowserType {

    HUB,
    LOCAL
}