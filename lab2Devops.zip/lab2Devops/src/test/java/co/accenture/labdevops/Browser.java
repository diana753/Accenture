package co.accenture.labdevops;

/**
 *
 * @author diego.tapia
 */
public enum Browser {

    FIREFOX,
    CHROME,
    IE
}